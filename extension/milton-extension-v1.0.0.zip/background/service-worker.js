// Milton Service Worker - Handles storage and Supabase sync

const STORAGE_KEY = 'milton_snips';
const AUTH_KEY = 'milton_auth';

// Supabase config
const SUPABASE_URL = 'https://jdrhajabucokwfnlyaix.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpkcmhhamFidWNva3dmbmx5YWl4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk3MjA1MzMsImV4cCI6MjA4NTI5NjUzM30.xJ-2l3J6FqtC3K7ihwjSXsXWpJ2SfMHJbthwpGQZlgA';

// Queue for sequential save operations to prevent race conditions
let saveQueue = Promise.resolve();

/**
 * Get auth session from storage
 */
async function getAuthSession() {
  const result = await chrome.storage.local.get(AUTH_KEY);
  return result[AUTH_KEY] || null;
}

/**
 * Save auth session to storage
 */
async function saveAuthSession(session) {
  await chrome.storage.local.set({ [AUTH_KEY]: session });

}

/**
 * Clear auth session
 */
async function clearAuthSession() {
  await chrome.storage.local.remove(AUTH_KEY);

}

/**
 * Make authenticated Supabase request
 */
async function supabaseRequest(endpoint, options = {}) {
  const session = await getAuthSession();

  const headers = {
    'Content-Type': 'application/json',
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': session?.access_token
      ? `Bearer ${session.access_token}`
      : `Bearer ${SUPABASE_ANON_KEY}`
  };

  const response = await fetch(`${SUPABASE_URL}/rest/v1${endpoint}`, {
    ...options,
    headers: { ...headers, ...options.headers }
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Supabase error: ${response.status} - ${error}`);
  }

  // Return null for 204 No Content responses (like DELETE)
  if (response.status === 204) {
    return null;
  }

  return response.json();
}

/**
 * Generate video summary in the background
 */
async function generateVideoSummary(videoId, transcript, title) {
  try {

    const summaryData = await invokeEdgeFunction('summary', {
      transcript,
      videoTitle: title
    });

    // Update summary row with results
    const updated = await supabaseRequest(`/summaries?video_id=eq.${videoId}`, {
      method: 'PATCH',
      headers: { 'Prefer': 'return=representation' },
      body: JSON.stringify({
        main_point: summaryData.overview || summaryData.mainPoint || '',
        key_takeaways: summaryData.takeaways || summaryData.keyTakeaways || [],
        status: 'completed'
      })
    });

    if (!updated || updated.length === 0) {

    } else {

    }
  } catch (error) {

    // Mark as failed
    try {
      await supabaseRequest(`/summaries?video_id=eq.${videoId}`, {
        method: 'PATCH',
        headers: { 'Prefer': 'return=representation' },
        body: JSON.stringify({ status: 'failed' })
      });

    } catch (patchError) {

    }
  }
}

/**
 * Get or create video in Supabase
 * Returns { videoId, transcriptData } - transcriptData is only populated for new videos
 */
async function getOrCreateVideo(session, snip) {
  // First, check if video exists
  const videos = await supabaseRequest(
    `/videos?youtube_id=eq.${snip.videoId}&user_id=eq.${session.user.id}&select=id`,
    { method: 'GET' }
  );

  if (videos && videos.length > 0) {
    return { videoId: videos[0].id, transcriptData: null };
  }

  // Fetch transcript for new video

  let transcriptData = null;
  let hasTranscript = false;

  try {
    transcriptData = await invokeEdgeFunction('transcript', { videoId: snip.videoId });
    hasTranscript = !transcriptData.error && !transcriptData.noCaptions && transcriptData.segments?.length > 0;
  } catch (error) {

  }

  // Create new video with transcript data if available
  const newVideo = await supabaseRequest('/videos', {
    method: 'POST',
    headers: { 'Prefer': 'return=representation' },
    body: JSON.stringify({
      user_id: session.user.id,
      youtube_id: snip.videoId,
      youtube_url: `https://www.youtube.com/watch?v=${snip.videoId}`,
      title: snip.videoTitle,
      author: snip.videoAuthor,
      thumbnail_url: snip.thumbnailUrl,
      status: 'in_progress',
      transcript: hasTranscript ? transcriptData.segments : null,
      transcript_raw: hasTranscript ? transcriptData.rawText : null
    })
  });

  const dbVideoId = newVideo[0].id;

  // Create pending summary and generate in background
  if (hasTranscript) {
    try {
      const summaryRow = await supabaseRequest('/summaries', {
        method: 'POST',
        headers: { 'Prefer': 'return=representation' },
        body: JSON.stringify({ video_id: dbVideoId, status: 'pending' })
      });

      // Generate summary in background (non-blocking)
      generateVideoSummary(dbVideoId, transcriptData.rawText, snip.videoTitle)
        .catch(() => {});
    } catch (error) {

    }
  }

  return { videoId: dbVideoId, transcriptData: hasTranscript ? transcriptData : null };
}

/**
 * Invoke a Supabase edge function
 */
async function invokeEdgeFunction(functionName, body) {
  const session = await getAuthSession();
  const url = `${SUPABASE_URL}/functions/v1/${functionName}`;

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${session?.access_token || SUPABASE_ANON_KEY}`,
      'apikey': SUPABASE_ANON_KEY
    },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    const error = await response.text();

    throw new Error(`Edge function error: ${response.status} - ${error}`);
  }

  const data = await response.json();

  return data;
}

/**
 * Get transcript context around a timestamp
 */
function getTranscriptContext(segments, timestampSeconds, beforeWindow = 30, afterWindow = 15) {
  if (!segments || segments.length === 0) return { context: '', startSeconds: 0, endSeconds: 0 };

  const startTime = Math.max(0, timestampSeconds - beforeWindow);
  const endTime = timestampSeconds + afterWindow;

  const relevantSegments = segments.filter(
    segment => segment.start >= startTime && segment.start <= endTime
  );

  return {
    context: relevantSegments.map(s => s.text).join(' '),
    startSeconds: startTime,
    endSeconds: endTime
  };
}

/**
 * Generate AI notes for a snip using Claude
 * @param {Object} snip - The snip data
 * @param {string} snipId - The Supabase snip ID
 * @param {Object|null} existingTranscriptData - Optional pre-fetched transcript data
 */
async function generateAINotes(snip, snipId, existingTranscriptData = null) {
  try {
    // Use existing transcript data or fetch it
    let transcriptData = existingTranscriptData;
    if (!transcriptData) {

      transcriptData = await invokeEdgeFunction('transcript', { videoId: snip.videoId });
    } else {

    }

    if (transcriptData.error || transcriptData.noCaptions || !transcriptData.segments?.length) {

      return null;
    }

    // Get context around the timestamp
    const { context, startSeconds, endSeconds } = getTranscriptContext(
      transcriptData.segments,
      snip.timestampSeconds
    );

    if (!context) {

      return null;
    }

    // Generate snip content with Claude

    const aiSnip = await invokeEdgeFunction('snip', {
      context,
      timestamp: snip.timestampSeconds,
      videoTitle: snip.videoTitle,
      startSeconds,
      endSeconds
    });

    if (aiSnip.error) {

      return null;
    }

    // Update snip in Supabase with AI-generated content
    await supabaseRequest(`/snips?id=eq.${snipId}`, {
      method: 'PATCH',
      headers: { 'Prefer': 'return=representation' },
      body: JSON.stringify({
        title: aiSnip.title,
        bullets: aiSnip.bullets || [],
        quote: aiSnip.quote,
        speaker: aiSnip.speaker,
        ai_generated: true
      })
    });

    return aiSnip;
  } catch (error) {

    return null;
  }
}

/**
 * Sync snip to Supabase
 */
async function syncSnipToSupabase(snip) {
  const session = await getAuthSession();

  if (!session?.access_token || !session?.user?.id) {

    return null;
  }

  try {
    // Get or create the video first (also fetches transcript for new videos)
    const { videoId, transcriptData } = await getOrCreateVideo(session, snip);

    // Create snip in Supabase
    const newSnip = await supabaseRequest('/snips', {
      method: 'POST',
      headers: { 'Prefer': 'return=representation' },
      body: JSON.stringify({
        user_id: session.user.id,
        video_id: videoId,
        title: snip.title,
        timestamp_seconds: Math.floor(snip.timestampSeconds),
        timestamp_formatted: snip.timestampFormatted,
        bullets: [],
        ai_generated: false
      })
    });

    // Generate AI notes in the background (don't block the snip save)
    // Reuse transcript data if available from video creation
    const supabaseSnipId = newSnip[0]?.id;
    if (supabaseSnipId) {
      generateAINotes(snip, supabaseSnipId, transcriptData).then(result => {
        if (result) {

        }
      }).catch(err => {

      });
    } else {

    }

    return newSnip[0];
  } catch (error) {

    return null;
  }
}

/**
 * Get all snips from local storage
 */
async function getSnips() {
  const result = await chrome.storage.local.get(STORAGE_KEY);
  return result[STORAGE_KEY] || [];
}

/**
 * Save a snip to local storage and sync to Supabase
 */
async function saveSnip(snip) {
  // Chain this save operation to the queue
  saveQueue = saveQueue.then(async () => {
    // Save locally first
    const snips = await getSnips();
    snips.push(snip);
    await chrome.storage.local.set({ [STORAGE_KEY]: snips });

    // Sync to Supabase (non-blocking)
    syncSnipToSupabase(snip).catch(err => {

    });

    return snip;
  }).catch(error => {

    throw error;
  });

  return saveQueue;
}

/**
 * Delete a snip by ID from local storage
 */
async function deleteSnip(snipId) {
  saveQueue = saveQueue.then(async () => {
    const snips = await getSnips();
    const filtered = snips.filter(s => s.id !== snipId);
    await chrome.storage.local.set({ [STORAGE_KEY]: filtered });

  }).catch(error => {

    throw error;
  });

  return saveQueue;
}

/**
 * Clear all snips from local storage
 */
async function clearAllSnips() {
  await chrome.storage.local.set({ [STORAGE_KEY]: [] });

}

// Listen for messages from content script and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'SAVE_SNIP':
      saveSnip(message.snip)
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true; // Keep channel open for async response

    case 'GET_SNIPS':
      getSnips()
        .then(snips => sendResponse({ success: true, snips }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;

    case 'DELETE_SNIP':
      deleteSnip(message.snipId)
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;

    case 'CLEAR_ALL_SNIPS':
      clearAllSnips()
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;

    case 'SET_AUTH_SESSION':
      saveAuthSession(message.session)
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;

    case 'GET_AUTH_SESSION':
      getAuthSession()
        .then(session => sendResponse({ success: true, session }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;

    case 'CLEAR_AUTH_SESSION':
      clearAuthSession()
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;

    default:

      sendResponse({ success: false, error: 'Unknown message type' });
  }
});

// Listen for external messages from the web app
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  // Verify sender is our web app
  const allowedOrigins = [
    'http://localhost:5173',
    'http://localhost:5174',
    'https://milton.video',
    'https://www.milton.video',
    'https://milton-chi.vercel.app'
  ];

  if (!allowedOrigins.some(origin => sender.url?.startsWith(origin))) {

    sendResponse({ success: false, error: 'Unauthorized origin' });
    return;
  }

  switch (message.type) {
    case 'SET_AUTH_SESSION':
      saveAuthSession(message.session)
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;

    case 'GET_AUTH_STATUS':
      getAuthSession()
        .then(session => sendResponse({
          success: true,
          authenticated: !!session?.access_token,
          user: session?.user || null
        }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;

    case 'CLEAR_AUTH_SESSION':
      clearAuthSession()
        .then(() => sendResponse({ success: true }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true;

    default:

      sendResponse({ success: false, error: 'Unknown message type' });
  }
});
